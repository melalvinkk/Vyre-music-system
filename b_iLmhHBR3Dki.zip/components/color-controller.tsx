'use client'

import { X, Palette, Zap, Moon, Eye } from 'lucide-react'
import { useMusicStore, type ColorPreset } from '@/lib/store'
import { cn } from '@/lib/utils'

const presets: { id: ColorPreset; name: string; description: string; icon: React.ReactNode }[] = [
  { id: 'auto', name: 'Auto', description: 'Colors from album art', icon: <Palette className="w-4 h-4" /> },
  { id: 'chill', name: 'Chill', description: 'Low saturation, calm', icon: <Moon className="w-4 h-4" /> },
  { id: 'neon', name: 'Neon', description: 'High saturation, vivid', icon: <Zap className="w-4 h-4" /> },
  { id: 'minimal', name: 'Minimal', description: 'Grayscale UI', icon: <Eye className="w-4 h-4" /> },
]

const colorOptions = [
  '#1DB954', // Spotify green
  '#DC2626', // Red
  '#2563EB', // Blue
  '#7C3AED', // Purple
  '#EC4899', // Pink
  '#F59E0B', // Amber
  '#06B6D4', // Cyan
  '#10B981', // Emerald
]

export function ColorController() {
  const { settings, updateSettings, setCustomizationOpen, customizationOpen } = useMusicStore()
  const shouldAnimate = !settings.lowStimulusMode && !settings.performanceMode

  if (!customizationOpen) return null

  return (
    <div className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm flex items-end justify-center">
      <div 
        className={cn(
          'w-full max-w-md bg-card rounded-t-3xl overflow-hidden',
          shouldAnimate && 'animate-in slide-in-from-bottom duration-300'
        )}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h2 className="text-lg font-bold">Customize</h2>
          <button
            onClick={() => setCustomizationOpen(false)}
            className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-6 max-h-[70vh] overflow-y-auto">
          {/* Presets */}
          <div>
            <h3 className="text-sm font-semibold text-muted-foreground mb-3">Color Presets</h3>
            <div className="grid grid-cols-2 gap-2">
              {presets.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => {
                    updateSettings({ 
                      preset: preset.id,
                      autoColor: preset.id === 'auto',
                    })
                  }}
                  className={cn(
                    'flex items-center gap-3 p-3 rounded-xl text-left',
                    shouldAnimate && 'transition-all duration-200',
                    settings.preset === preset.id
                      ? 'bg-white text-black'
                      : 'bg-secondary hover:bg-secondary/80'
                  )}
                >
                  {preset.icon}
                  <div>
                    <p className="font-semibold text-sm">{preset.name}</p>
                    <p className={cn(
                      'text-xs',
                      settings.preset === preset.id ? 'text-black/60' : 'text-muted-foreground'
                    )}>
                      {preset.description}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Manual Color Picker */}
          {!settings.autoColor && settings.preset !== 'minimal' && (
            <div>
              <h3 className="text-sm font-semibold text-muted-foreground mb-3">Accent Color</h3>
              <div className="flex gap-2 flex-wrap">
                {colorOptions.map((color) => (
                  <button
                    key={color}
                    onClick={() => updateSettings({ manualColor: color })}
                    className={cn(
                      'w-10 h-10 rounded-full',
                      shouldAnimate && 'transition-all duration-200',
                      settings.manualColor === color && 'ring-2 ring-white ring-offset-2 ring-offset-card'
                    )}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Intensity Slider */}
          {settings.preset !== 'minimal' && (
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-muted-foreground">Color Intensity</h3>
                <span className="text-sm text-muted-foreground">
                  {Math.round(settings.intensity * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.intensity * 100}
                onChange={(e) => updateSettings({ intensity: parseInt(e.target.value) / 100 })}
                className="w-full h-2 bg-secondary rounded-full appearance-none cursor-pointer accent-white"
              />
            </div>
          )}

          {/* Accessibility Options */}
          <div>
            <h3 className="text-sm font-semibold text-muted-foreground mb-3">Accessibility</h3>
            <div className="space-y-3">
              <label className="flex items-center justify-between p-3 bg-secondary rounded-xl cursor-pointer">
                <div>
                  <p className="font-semibold text-sm">Low Stimulus Mode</p>
                  <p className="text-xs text-muted-foreground">Reduce animations and colors</p>
                </div>
                <div className={cn(
                  'w-12 h-7 rounded-full p-1',
                  shouldAnimate && 'transition-colors duration-200',
                  settings.lowStimulusMode ? 'bg-white' : 'bg-border'
                )}>
                  <div className={cn(
                    'w-5 h-5 rounded-full',
                    shouldAnimate && 'transition-transform duration-200',
                    settings.lowStimulusMode 
                      ? 'bg-black translate-x-5' 
                      : 'bg-muted-foreground translate-x-0'
                  )} />
                </div>
                <input
                  type="checkbox"
                  className="sr-only"
                  checked={settings.lowStimulusMode}
                  onChange={(e) => updateSettings({ lowStimulusMode: e.target.checked })}
                />
              </label>

              <label className="flex items-center justify-between p-3 bg-secondary rounded-xl cursor-pointer">
                <div>
                  <p className="font-semibold text-sm">Performance Mode</p>
                  <p className="text-xs text-muted-foreground">Disable animations and effects</p>
                </div>
                <div className={cn(
                  'w-12 h-7 rounded-full p-1',
                  shouldAnimate && 'transition-colors duration-200',
                  settings.performanceMode ? 'bg-white' : 'bg-border'
                )}>
                  <div className={cn(
                    'w-5 h-5 rounded-full',
                    shouldAnimate && 'transition-transform duration-200',
                    settings.performanceMode 
                      ? 'bg-black translate-x-5' 
                      : 'bg-muted-foreground translate-x-0'
                  )} />
                </div>
                <input
                  type="checkbox"
                  className="sr-only"
                  checked={settings.performanceMode}
                  onChange={(e) => updateSettings({ performanceMode: e.target.checked })}
                />
              </label>

              <label className="flex items-center justify-between p-3 bg-secondary rounded-xl cursor-pointer">
                <div>
                  <p className="font-semibold text-sm">Swipe Gestures</p>
                  <p className="text-xs text-muted-foreground">Enable swipe to skip songs</p>
                </div>
                <div className={cn(
                  'w-12 h-7 rounded-full p-1',
                  shouldAnimate && 'transition-colors duration-200',
                  settings.swipeGestures ? 'bg-white' : 'bg-border'
                )}>
                  <div className={cn(
                    'w-5 h-5 rounded-full',
                    shouldAnimate && 'transition-transform duration-200',
                    settings.swipeGestures 
                      ? 'bg-black translate-x-5' 
                      : 'bg-muted-foreground translate-x-0'
                  )} />
                </div>
                <input
                  type="checkbox"
                  className="sr-only"
                  checked={settings.swipeGestures}
                  onChange={(e) => updateSettings({ swipeGestures: e.target.checked })}
                />
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
