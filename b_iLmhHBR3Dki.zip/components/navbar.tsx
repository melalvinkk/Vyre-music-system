'use client'

import { Home, Search, Library } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useMusicStore } from '@/lib/store'

interface NavbarProps {
  activeTab: 'home' | 'search' | 'library'
  onTabChange: (tab: 'home' | 'search' | 'library') => void
}

export function Navbar({ activeTab, onTabChange }: NavbarProps) {
  const { settings } = useMusicStore()
  const shouldAnimate = !settings.lowStimulusMode && !settings.performanceMode

  const tabs = [
    { id: 'home' as const, label: 'Home', icon: Home },
    { id: 'search' as const, label: 'Search', icon: Search },
    { id: 'library' as const, label: 'Library', icon: Library },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-black/90 backdrop-blur-xl border-t border-border/50">
      <div className="flex items-center justify-around px-4 py-2 max-w-md mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon
          const isActive = activeTab === tab.id
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={cn(
                'flex flex-col items-center gap-1 py-2 px-6 rounded-xl',
                shouldAnimate && 'transition-all duration-200',
                isActive 
                  ? 'text-white' 
                  : 'text-muted-foreground hover:text-white'
              )}
            >
              <Icon className={cn(
                'w-6 h-6',
                shouldAnimate && 'transition-transform duration-200',
                isActive && 'scale-110'
              )} />
              <span className="text-xs font-medium">{tab.label}</span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
