'use client'

import { useState } from 'react'
import { Plus, Heart, Music2, ListMusic, X } from 'lucide-react'
import { useMusicStore } from '@/lib/store'
import { SongCard } from '@/components/song-card'
import { PlaylistCard } from '@/components/playlist-card'
import { cn } from '@/lib/utils'

type LibraryTab = 'playlists' | 'liked'

export function LibraryScreen() {
  const [activeTab, setActiveTab] = useState<LibraryTab>('playlists')
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [newPlaylistName, setNewPlaylistName] = useState('')
  
  const { likedSongs, playlists, createPlaylist, playQueue, settings } = useMusicStore()
  const shouldAnimate = !settings.lowStimulusMode && !settings.performanceMode

  const handleCreatePlaylist = () => {
    if (newPlaylistName.trim()) {
      createPlaylist(newPlaylistName.trim())
      setNewPlaylistName('')
      setShowCreateModal(false)
    }
  }

  return (
    <div className="pb-[140px] pt-4">
      {/* Header */}
      <div className="px-5 mb-4">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold">Your Library</h1>
          <button
            onClick={() => setShowCreateModal(true)}
            className={cn(
              'w-10 h-10 rounded-full bg-card flex items-center justify-center',
              shouldAnimate && 'transition-transform duration-150 active:scale-90'
            )}
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('playlists')}
            className={cn(
              'flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium',
              shouldAnimate && 'transition-all duration-200',
              activeTab === 'playlists'
                ? 'bg-white text-black'
                : 'bg-card text-foreground hover:bg-card/80'
            )}
          >
            <ListMusic className="w-4 h-4" />
            Playlists
          </button>
          <button
            onClick={() => setActiveTab('liked')}
            className={cn(
              'flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium',
              shouldAnimate && 'transition-all duration-200',
              activeTab === 'liked'
                ? 'bg-white text-black'
                : 'bg-card text-foreground hover:bg-card/80'
            )}
          >
            <Heart className="w-4 h-4" />
            Liked Songs
          </button>
        </div>
      </div>

      {/* Content */}
      {activeTab === 'playlists' && (
        <div className="px-5">
          {/* Liked Songs Card */}
          {likedSongs.length > 0 && (
            <button
              onClick={() => playQueue(likedSongs)}
              className={cn(
                'w-full flex items-center gap-4 p-3 bg-card rounded-xl mb-4',
                shouldAnimate && 'transition-all duration-200',
                'hover:bg-card/80 active:scale-[0.99]'
              )}
            >
              <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-purple-600 to-blue-400 flex items-center justify-center">
                <Heart className="w-7 h-7 text-white fill-white" />
              </div>
              <div className="flex-1 text-left">
                <p className="font-bold">Liked Songs</p>
                <p className="text-sm text-muted-foreground">{likedSongs.length} songs</p>
              </div>
            </button>
          )}

          {/* User Playlists */}
          {playlists.length > 0 ? (
            <div className="space-y-3">
              <h2 className="text-lg font-bold">Your Playlists</h2>
              <div className="grid grid-cols-2 gap-3">
                {playlists.map((playlist) => (
                  <PlaylistCard key={playlist.id} playlist={playlist} variant="large" />
                ))}
              </div>
            </div>
          ) : (
            <div className="py-12 text-center">
              <div className="w-16 h-16 rounded-full bg-card flex items-center justify-center mx-auto mb-4">
                <Music2 className="w-8 h-8 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground">No playlists yet</p>
              <p className="text-sm text-muted-foreground mt-1">Create your first playlist</p>
              <button
                onClick={() => setShowCreateModal(true)}
                className={cn(
                  'mt-4 px-6 py-2 bg-white text-black rounded-full font-semibold text-sm',
                  shouldAnimate && 'transition-transform duration-150 active:scale-95'
                )}
              >
                Create Playlist
              </button>
            </div>
          )}
        </div>
      )}

      {activeTab === 'liked' && (
        <div className="px-5">
          {likedSongs.length > 0 ? (
            <div className="space-y-1">
              {likedSongs.map((song, index) => (
                <SongCard key={song.id} song={song} variant="list" index={index} />
              ))}
            </div>
          ) : (
            <div className="py-12 text-center">
              <div className="w-16 h-16 rounded-full bg-card flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground">No liked songs yet</p>
              <p className="text-sm text-muted-foreground mt-1">Songs you like will appear here</p>
            </div>
          )}
        </div>
      )}

      {/* Create Playlist Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-[70] bg-black/80 backdrop-blur-sm flex items-center justify-center p-5">
          <div 
            className={cn(
              'w-full max-w-sm bg-card rounded-2xl overflow-hidden',
              shouldAnimate && 'animate-in zoom-in-95 duration-200'
            )}
          >
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h2 className="text-lg font-bold">Create Playlist</h2>
              <button
                onClick={() => setShowCreateModal(false)}
                className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4">
              <input
                type="text"
                value={newPlaylistName}
                onChange={(e) => setNewPlaylistName(e.target.value)}
                placeholder="Playlist name"
                autoFocus
                className={cn(
                  'w-full h-12 px-4 bg-secondary rounded-xl text-foreground placeholder:text-muted-foreground',
                  'focus:outline-none focus:ring-2 focus:ring-white/20'
                )}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleCreatePlaylist()
                }}
              />
              <div className="flex gap-3 mt-4">
                <button
                  onClick={() => setShowCreateModal(false)}
                  className={cn(
                    'flex-1 py-3 bg-secondary rounded-xl font-semibold',
                    shouldAnimate && 'transition-transform duration-150 active:scale-95'
                  )}
                >
                  Cancel
                </button>
                <button
                  onClick={handleCreatePlaylist}
                  disabled={!newPlaylistName.trim()}
                  className={cn(
                    'flex-1 py-3 bg-white text-black rounded-xl font-semibold',
                    shouldAnimate && 'transition-transform duration-150 active:scale-95',
                    !newPlaylistName.trim() && 'opacity-50'
                  )}
                >
                  Create
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
