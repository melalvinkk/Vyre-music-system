'use client'

import { useMusicStore, type Song, type Playlist } from '@/lib/store'
import { useSongs } from '@/hooks/use-songs'
import { SongCard } from '@/components/song-card'
import { PlaylistCard } from '@/components/playlist-card'
import { cn } from '@/lib/utils'
import { Loader2 } from 'lucide-react'

export function HomeScreen() {
  const { recentlyPlayed, settings, playQueue } = useMusicStore()
  const { songs, isLoading } = useSongs()
  const shouldAnimate = !settings.lowStimulusMode && !settings.performanceMode
  
  // Use fetched songs or empty array while loading
  const vibeNowSongs = recentlyPlayed.length > 0 ? recentlyPlayed.slice(0, 6) : songs.slice(0, 6)
  const recommendedSongs = songs.slice(0, 8)
  const madeForYou = songs.slice(6, 12)

  // Create mood playlists from fetched songs
  const moodPlaylists: Playlist[] = songs.length > 0 ? [
    {
      id: 'mood-1',
      name: 'Chill Vibes',
      songs: [songs[0], songs[5], songs[9], songs[11]].filter(Boolean) as Song[],
      coverImage: songs[0]?.coverImage || '',
    },
    {
      id: 'mood-2',
      name: 'Energy Boost',
      songs: [songs[1], songs[4], songs[10], songs[15]].filter(Boolean) as Song[],
      coverImage: songs[1]?.coverImage || '',
    },
    {
      id: 'mood-3',
      name: 'Late Night',
      songs: [songs[2], songs[3], songs[9], songs[13]].filter(Boolean) as Song[],
      coverImage: songs[2]?.coverImage || '',
    },
    {
      id: 'mood-4',
      name: 'Feel Good',
      songs: [songs[7], songs[8], songs[14], songs[6]].filter(Boolean) as Song[],
      coverImage: songs[7]?.coverImage || '',
    },
  ] : []

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-accent" />
          <p className="text-muted-foreground">Loading your music...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="pb-[140px] pt-4">
      {/* Header */}
      <div className="px-5 mb-6">
        <h1 className="text-2xl font-bold">Good evening</h1>
        <p className="text-muted-foreground text-sm mt-1">What do you want to listen to?</p>
      </div>

      {/* Quick Play Grid */}
      {moodPlaylists.length > 0 && (
        <div className="px-5 mb-8">
          <div className="grid grid-cols-2 gap-2">
            {moodPlaylists.slice(0, 4).map((playlist) => (
              <button
                key={playlist.id}
                onClick={() => playQueue(playlist.songs)}
                className={cn(
                  'flex items-center gap-3 bg-card/60 rounded-lg overflow-hidden',
                  shouldAnimate && 'transition-all duration-200',
                  'hover:bg-card active:scale-[0.98]'
                )}
              >
                <div className="relative w-14 h-14 flex-shrink-0">
                  <img
                    src={playlist.coverImage}
                    alt={playlist.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <span className="font-semibold text-sm pr-2 truncate">{playlist.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Your Vibe Now */}
      {vibeNowSongs.length > 0 && (
        <section className="mb-8">
          <div className="px-5 mb-4">
            <h2 className="text-xl font-bold">Your Vibe Now</h2>
            <p className="text-muted-foreground text-sm">Recently played</p>
          </div>
          <div className="flex gap-4 overflow-x-auto px-5 pb-2 scrollbar-hide">
            {vibeNowSongs.map((song) => (
              <SongCard key={song.id} song={song} />
            ))}
          </div>
        </section>
      )}

      {/* Recommended */}
      {recommendedSongs.length > 0 && (
        <section className="mb-8">
          <div className="px-5 mb-4">
            <h2 className="text-xl font-bold">Recommended for You</h2>
            <p className="text-muted-foreground text-sm">Based on your listening</p>
          </div>
          <div className="flex gap-4 overflow-x-auto px-5 pb-2 scrollbar-hide">
            {recommendedSongs.map((song) => (
              <SongCard key={song.id} song={song} />
            ))}
          </div>
        </section>
      )}

      {/* Mood Playlists */}
      {moodPlaylists.length > 0 && (
        <section className="mb-8">
          <div className="px-5 mb-4">
            <h2 className="text-xl font-bold">Mood Playlists</h2>
            <p className="text-muted-foreground text-sm">For every moment</p>
          </div>
          <div className="flex gap-4 overflow-x-auto px-5 pb-2 scrollbar-hide">
            {moodPlaylists.map((playlist) => (
              <PlaylistCard key={playlist.id} playlist={playlist} />
            ))}
          </div>
        </section>
      )}

      {/* Made for You */}
      {madeForYou.length > 0 && (
        <section className="mb-8">
          <div className="px-5 mb-4">
            <h2 className="text-xl font-bold">Made for You</h2>
            <p className="text-muted-foreground text-sm">Your personal mix</p>
          </div>
          <div className="flex gap-4 overflow-x-auto px-5 pb-2 scrollbar-hide">
            {madeForYou.map((song) => (
              <SongCard key={song.id} song={song} />
            ))}
          </div>
        </section>
      )}
    </div>
  )
}
