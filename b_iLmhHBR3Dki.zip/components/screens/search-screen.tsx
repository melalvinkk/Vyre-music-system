'use client'

import { useState, useMemo } from 'react'
import { Search, X, Loader2 } from 'lucide-react'
import { useSongs, searchSongs } from '@/hooks/use-songs'
import { SongCard } from '@/components/song-card'
import { useMusicStore, type Playlist, type Song } from '@/lib/store'
import { cn } from '@/lib/utils'

export function SearchScreen() {
  const [query, setQuery] = useState('')
  const { settings, playQueue } = useMusicStore()
  const { songs, isLoading } = useSongs()
  const shouldAnimate = !settings.lowStimulusMode && !settings.performanceMode

  const searchResults = useMemo(() => {
    if (!query.trim()) return []
    return searchSongs(songs, query)
  }, [query, songs])

  // Create browse categories with real song images
  const browseCategories = useMemo(() => {
    if (songs.length === 0) return []
    return [
      { id: '1', name: 'Pop', color: '#DC2626', image: songs[1]?.coverImage || '' },
      { id: '2', name: 'Hip-Hop', color: '#7C3AED', image: songs[6]?.coverImage || '' },
      { id: '3', name: 'Rock', color: '#EA580C', image: songs[10]?.coverImage || '' },
      { id: '4', name: 'Electronic', color: '#06B6D4', image: songs[3]?.coverImage || '' },
      { id: '5', name: 'Jazz', color: '#059669', image: songs[9]?.coverImage || '' },
      { id: '6', name: 'Classical', color: '#F59E0B', image: songs[12]?.coverImage || '' },
      { id: '7', name: 'R&B', color: '#EC4899', image: songs[8]?.coverImage || '' },
      { id: '8', name: 'Indie', color: '#10B981', image: songs[0]?.coverImage || '' },
    ]
  }, [songs])

  // Create mood playlists from fetched songs for random play
  const moodPlaylists: Playlist[] = useMemo(() => {
    if (songs.length < 12) return []
    return [
      {
        id: 'mood-1',
        name: 'Chill Vibes',
        songs: [songs[0], songs[5], songs[9], songs[11]].filter(Boolean) as Song[],
        coverImage: songs[0]?.coverImage || '',
      },
      {
        id: 'mood-2',
        name: 'Energy Boost',
        songs: [songs[1], songs[4], songs[10], songs[15]].filter(Boolean) as Song[],
        coverImage: songs[1]?.coverImage || '',
      },
    ]
  }, [songs])

  const hasResults = searchResults.length > 0
  const showBrowse = !query.trim()

  if (isLoading) {
    return (
      <div className="pb-[140px] pt-4">
        <div className="px-5 mb-4">
          <h1 className="text-2xl font-bold mb-4">Search</h1>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              disabled
              placeholder="Loading..."
              className="w-full h-12 pl-12 pr-10 bg-card rounded-xl text-foreground placeholder:text-muted-foreground opacity-50"
            />
          </div>
        </div>
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-accent" />
        </div>
      </div>
    )
  }

  return (
    <div className="pb-[140px] pt-4">
      {/* Header */}
      <div className="px-5 mb-4">
        <h1 className="text-2xl font-bold mb-4">Search</h1>
        
        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Songs, artists, or albums"
            className={cn(
              'w-full h-12 pl-12 pr-10 bg-card rounded-xl text-foreground placeholder:text-muted-foreground',
              'focus:outline-none focus:ring-2 focus:ring-white/20',
              shouldAnimate && 'transition-all duration-200'
            )}
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-muted-foreground/50 flex items-center justify-center"
            >
              <X className="w-3 h-3 text-background" />
            </button>
          )}
        </div>
      </div>

      {/* Search Results */}
      {hasResults && (
        <div className="px-5">
          <h2 className="text-lg font-bold mb-3">Results</h2>
          <div className="space-y-1">
            {searchResults.map((song, index) => (
              <SongCard key={song.id} song={song} variant="list" index={index} />
            ))}
          </div>
        </div>
      )}

      {/* No Results */}
      {query && !hasResults && (
        <div className="px-5 py-12 text-center">
          <p className="text-muted-foreground">No results found for &quot;{query}&quot;</p>
          <p className="text-sm text-muted-foreground mt-1">Try different keywords</p>
        </div>
      )}

      {/* Browse Categories */}
      {showBrowse && (
        <div className="px-5">
          <h2 className="text-lg font-bold mb-4">Browse All</h2>
          <div className="grid grid-cols-2 gap-3">
            {browseCategories.map((category) => (
              <button
                key={category.id}
                onClick={() => {
                  // Play songs from mood playlists as a demo
                  if (moodPlaylists.length > 0) {
                    const playlist = moodPlaylists[Math.floor(Math.random() * moodPlaylists.length)]
                    playQueue(playlist.songs)
                  }
                }}
                className={cn(
                  'relative h-24 rounded-xl overflow-hidden',
                  shouldAnimate && 'transition-transform duration-200',
                  'active:scale-[0.97]'
                )}
                style={{ backgroundColor: category.color }}
              >
                <span className="absolute top-3 left-3 font-bold text-white">{category.name}</span>
                {category.image && (
                  <div 
                    className="absolute bottom-0 right-0 w-16 h-16 rotate-[25deg] translate-x-2 translate-y-2 rounded-md overflow-hidden shadow-lg"
                  >
                    <img
                      src={category.image}
                      alt={category.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
              </button>
            ))}
          </div>

          {/* Top Songs Section */}
          {songs.length > 0 && (
            <div className="mt-8">
              <h2 className="text-lg font-bold mb-3">Top Songs</h2>
              <div className="space-y-1">
                {songs.slice(0, 5).map((song, index) => (
                  <SongCard key={song.id} song={song} variant="list" index={index} />
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
