'use client'

import { useEffect, useRef, useCallback } from 'react'
import Image from 'next/image'
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  ChevronDown, 
  Heart,
  Undo2,
  Settings2,
  Volume2,
  VolumeX
} from 'lucide-react'
import { useMusicStore } from '@/lib/store'
import { cn } from '@/lib/utils'

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60)
  const secs = Math.floor(seconds % 60)
  return `${mins}:${secs.toString().padStart(2, '0')}`
}

export function Player() {
  const audioRef = useRef<HTMLAudioElement>(null)
  const progressRef = useRef<HTMLDivElement>(null)
  
  const {
    currentSong,
    isPlaying,
    currentTime,
    duration,
    volume,
    togglePlay,
    nextSong,
    previousSong,
    undoSkip,
    setCurrentTime,
    setDuration,
    setVolume,
    toggleLike,
    isLiked,
    playerOpen,
    setPlayerOpen,
    setCustomizationOpen,
    settings,
    history,
    setIsPlaying,
    stopPreview,
    isPreviewPlaying,
  } = useMusicStore()

  const shouldAnimate = !settings.lowStimulusMode && !settings.performanceMode
  const liked = currentSong ? isLiked(currentSong.id) : false

  // Get accent color based on settings
  const getAccentColor = useCallback(() => {
    if (settings.preset === 'minimal') return '#888888'
    if (settings.autoColor && currentSong) {
      return currentSong.dominantColor
    }
    return settings.manualColor
  }, [settings, currentSong])

  const accentColor = getAccentColor()

  // Apply intensity to color
  const getAdjustedColor = useCallback(() => {
    if (settings.preset === 'chill') {
      return accentColor + '99' // 60% opacity for chill
    }
    if (settings.preset === 'neon') {
      return accentColor // Full saturation
    }
    // Apply intensity
    const opacity = Math.round(settings.intensity * 255).toString(16).padStart(2, '0')
    return accentColor + opacity
  }, [accentColor, settings])

  // Audio event handlers
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const handleTimeUpdate = () => setCurrentTime(audio.currentTime)
    const handleLoadedMetadata = () => setDuration(audio.duration)
    const handleEnded = () => nextSong()
    const handlePlay = () => setIsPlaying(true)
    const handlePause = () => setIsPlaying(false)

    audio.addEventListener('timeupdate', handleTimeUpdate)
    audio.addEventListener('loadedmetadata', handleLoadedMetadata)
    audio.addEventListener('ended', handleEnded)
    audio.addEventListener('play', handlePlay)
    audio.addEventListener('pause', handlePause)

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate)
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata)
      audio.removeEventListener('ended', handleEnded)
      audio.removeEventListener('play', handlePlay)
      audio.removeEventListener('pause', handlePause)
    }
  }, [setCurrentTime, setDuration, nextSong, setIsPlaying])

  // Play/pause control
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    if (isPlaying) {
      // Stop any preview when main player starts
      if (isPreviewPlaying) {
        stopPreview()
      }
      audio.play().catch(() => {
        // Handle autoplay restrictions
        setIsPlaying(false)
      })
    } else {
      audio.pause()
    }
  }, [isPlaying, setIsPlaying, isPreviewPlaying, stopPreview])

  // Volume control
  useEffect(() => {
    const audio = audioRef.current
    if (audio) {
      audio.volume = volume
    }
  }, [volume])

  // Load new song
  useEffect(() => {
    const audio = audioRef.current
    if (!audio || !currentSong) return

    audio.src = currentSong.audioUrl
    audio.load()
    if (isPlaying) {
      audio.play().catch(() => {
        setIsPlaying(false)
      })
    }
  }, [currentSong, isPlaying, setIsPlaying])

  // Seek handler
  const handleSeek = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    const progressBar = progressRef.current
    const audio = audioRef.current
    if (!progressBar || !audio) return

    const rect = progressBar.getBoundingClientRect()
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX
    const percent = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width))
    const newTime = percent * duration
    
    audio.currentTime = newTime
    setCurrentTime(newTime)
  }

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0

  if (!currentSong) return null

  return (
    <>
      <audio ref={audioRef} preload="metadata" />
      
      {/* Full Screen Player */}
      {playerOpen && (
        <div 
          className={cn(
            'fixed inset-0 z-50 bg-black flex flex-col',
            shouldAnimate && 'animate-in slide-in-from-bottom duration-300'
          )}
          style={{
            '--accent': accentColor,
            background: settings.preset === 'minimal' 
              ? '#000000' 
              : `linear-gradient(180deg, ${getAdjustedColor()} 0%, #000000 50%)`,
          } as React.CSSProperties}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4">
            <button
              onClick={() => setPlayerOpen(false)}
              className={cn(
                'w-10 h-10 rounded-full flex items-center justify-center',
                'bg-white/10 backdrop-blur',
                shouldAnimate && 'transition-transform duration-150 active:scale-90'
              )}
            >
              <ChevronDown className="w-6 h-6" />
            </button>
            <span className="text-sm font-medium text-white/70">Now Playing</span>
            <button
              onClick={() => setCustomizationOpen(true)}
              className={cn(
                'w-10 h-10 rounded-full flex items-center justify-center',
                'bg-white/10 backdrop-blur',
                shouldAnimate && 'transition-transform duration-150 active:scale-90'
              )}
            >
              <Settings2 className="w-5 h-5" />
            </button>
          </div>

          {/* Album Art */}
          <div className="flex-1 flex items-center justify-center px-8 py-4">
            <div 
              className={cn(
                'relative w-full max-w-[320px] aspect-square rounded-2xl overflow-hidden shadow-2xl',
                shouldAnimate && 'transition-transform duration-300',
                isPlaying && shouldAnimate && 'scale-100',
                !isPlaying && shouldAnimate && 'scale-95'
              )}
            >
              <Image
                src={currentSong.coverImage}
                alt={currentSong.title}
                fill
                className="object-cover"
                sizes="320px"
                priority
              />
            </div>
          </div>

          {/* Song Info */}
          <div className="px-8 mb-4">
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <h1 className="text-2xl font-bold truncate">{currentSong.title}</h1>
                <p className="text-lg text-white/70 truncate">{currentSong.artist}</p>
              </div>
              <button
                onClick={() => toggleLike(currentSong)}
                className={cn(
                  'p-2 rounded-full',
                  shouldAnimate && 'transition-transform duration-150 active:scale-90'
                )}
              >
                <Heart className={cn(
                  'w-7 h-7',
                  shouldAnimate && 'transition-colors duration-200',
                  liked ? 'fill-white text-white' : 'text-white/70'
                )} />
              </button>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="px-8 mb-4">
            <div
              ref={progressRef}
              onClick={handleSeek}
              onTouchMove={handleSeek}
              className="relative h-2 bg-white/20 rounded-full cursor-pointer touch-none"
            >
              <div 
                className={cn(
                  'absolute inset-y-0 left-0 bg-white rounded-full',
                  shouldAnimate && 'transition-all duration-100'
                )}
                style={{ width: `${progress}%` }}
              />
              <div 
                className={cn(
                  'absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg',
                  shouldAnimate && 'transition-all duration-100'
                )}
                style={{ left: `calc(${progress}% - 8px)` }}
              />
            </div>
            <div className="flex justify-between mt-2 text-sm text-white/50">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Controls */}
          <div className="px-8 mb-8">
            <div className="flex items-center justify-center gap-6">
              {/* Undo Skip */}
              <button
                onClick={undoSkip}
                disabled={history.length === 0}
                className={cn(
                  'w-10 h-10 rounded-full flex items-center justify-center',
                  shouldAnimate && 'transition-all duration-150 active:scale-90',
                  history.length === 0 ? 'opacity-30' : 'opacity-70 hover:opacity-100'
                )}
              >
                <Undo2 className="w-5 h-5" />
              </button>

              {/* Previous */}
              <button
                onClick={previousSong}
                className={cn(
                  'w-12 h-12 rounded-full flex items-center justify-center',
                  shouldAnimate && 'transition-transform duration-150 active:scale-90'
                )}
              >
                <SkipBack className="w-7 h-7 fill-current" />
              </button>

              {/* Play/Pause */}
              <button
                onClick={togglePlay}
                className={cn(
                  'w-16 h-16 rounded-full bg-white text-black flex items-center justify-center',
                  shouldAnimate && 'transition-transform duration-150 active:scale-90'
                )}
              >
                {isPlaying ? (
                  <Pause className="w-8 h-8 fill-current" />
                ) : (
                  <Play className="w-8 h-8 fill-current ml-1" />
                )}
              </button>

              {/* Next */}
              <button
                onClick={nextSong}
                className={cn(
                  'w-12 h-12 rounded-full flex items-center justify-center',
                  shouldAnimate && 'transition-transform duration-150 active:scale-90'
                )}
              >
                <SkipForward className="w-7 h-7 fill-current" />
              </button>

              {/* Volume */}
              <button
                onClick={() => setVolume(volume > 0 ? 0 : 1)}
                className={cn(
                  'w-10 h-10 rounded-full flex items-center justify-center opacity-70 hover:opacity-100',
                  shouldAnimate && 'transition-all duration-150 active:scale-90'
                )}
              >
                {volume > 0 ? (
                  <Volume2 className="w-5 h-5" />
                ) : (
                  <VolumeX className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
