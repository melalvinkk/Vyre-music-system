'use client'

import Image from 'next/image'
import { Play, Pause } from 'lucide-react'
import { useMusicStore } from '@/lib/store'
import { cn } from '@/lib/utils'

export function MiniPlayer() {
  const { currentSong, isPlaying, togglePlay, setPlayerOpen, settings, currentTime, duration } = useMusicStore()
  const shouldAnimate = !settings.lowStimulusMode && !settings.performanceMode

  if (!currentSong) return null

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0

  return (
    <div 
      className="fixed bottom-[60px] left-0 right-0 z-30 px-2"
      style={{
        '--player-accent': settings.autoColor ? currentSong.dominantColor : settings.manualColor,
      } as React.CSSProperties}
    >
      <div
        className={cn(
          'w-full bg-card/95 backdrop-blur-xl rounded-xl overflow-hidden',
          'border border-border/50',
          shouldAnimate && 'transition-all duration-200'
        )}
      >
        <div className="flex items-center gap-3 p-2 pr-3">
          {/* Clickable area for opening player */}
          <div 
            onClick={() => setPlayerOpen(true)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && setPlayerOpen(true)}
            className={cn(
              'flex items-center gap-3 flex-1 min-w-0 cursor-pointer',
              shouldAnimate && 'transition-transform duration-200',
              'active:scale-[0.99]'
            )}
          >
            <div className="relative w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
              <Image
                src={currentSong.coverImage}
                alt={currentSong.title}
                fill
                className="object-cover"
                sizes="48px"
              />
            </div>
            <div className="flex-1 min-w-0 text-left">
              <p className="font-semibold text-sm truncate">{currentSong.title}</p>
              <p className="text-xs text-muted-foreground truncate">{currentSong.artist}</p>
            </div>
          </div>
          <button
            onClick={togglePlay}
            className={cn(
              'w-10 h-10 rounded-full flex items-center justify-center',
              'bg-white text-black',
              shouldAnimate && 'transition-transform duration-150 active:scale-90'
            )}
          >
            {isPlaying ? (
              <Pause className="w-5 h-5 fill-current" />
            ) : (
              <Play className="w-5 h-5 fill-current ml-0.5" />
            )}
          </button>
        </div>
        {/* Progress bar */}
        <div className="h-1 bg-border/50">
          <div 
            className={cn(
              'h-full bg-white',
              shouldAnimate && 'transition-all duration-100'
            )}
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  )
}
