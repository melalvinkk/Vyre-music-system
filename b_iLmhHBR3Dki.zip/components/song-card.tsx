'use client'

import { useRef, useEffect, useState } from 'react'
import Image from 'next/image'
import { Play, Pause, Heart, MoreHorizontal, Plus, Volume2 } from 'lucide-react'
import { useMusicStore, type Song } from '@/lib/store'
import { cn } from '@/lib/utils'

interface SongCardProps {
  song: Song
  variant?: 'default' | 'compact' | 'list'
  showArtist?: boolean
  index?: number
}

export function SongCard({ song, variant = 'default', showArtist = true, index }: SongCardProps) {
  const { 
    playSong, 
    toggleLike, 
    isLiked, 
    settings, 
    currentSong, 
    isPlaying,
    previewSong,
    isPreviewPlaying,
    startPreview,
    stopPreview,
    openAddToPlaylist,
    setPlayerOpen
  } = useMusicStore()
  
  const liked = isLiked(song.id)
  const isCurrentSong = currentSong?.id === song.id
  const isThisPreview = previewSong?.id === song.id
  const shouldAnimate = !settings.lowStimulusMode && !settings.performanceMode
  
  const previewAudioRef = useRef<HTMLAudioElement | null>(null)
  const [showMenu, setShowMenu] = useState(false)

  // Handle preview audio
  useEffect(() => {
    if (isThisPreview && isPreviewPlaying) {
      if (!previewAudioRef.current) {
        previewAudioRef.current = new Audio(song.previewUrl || song.audioUrl)
        previewAudioRef.current.volume = 0.5
      }
      previewAudioRef.current.play()
      
      // Stop preview after 15 seconds
      const timeout = setTimeout(() => {
        stopPreview()
      }, 15000)
      
      return () => {
        clearTimeout(timeout)
        if (previewAudioRef.current) {
          previewAudioRef.current.pause()
          previewAudioRef.current.currentTime = 0
        }
      }
    } else if (previewAudioRef.current) {
      previewAudioRef.current.pause()
      previewAudioRef.current.currentTime = 0
    }
  }, [isThisPreview, isPreviewPlaying, song.previewUrl, song.audioUrl, stopPreview])

  const handleImageClick = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (isThisPreview && isPreviewPlaying) {
      stopPreview()
    } else {
      // Stop any existing preview first
      stopPreview()
      // Pause main player if playing to avoid overlap
      if (isPlaying) {
        useMusicStore.getState().setIsPlaying(false)
      }
      startPreview(song)
    }
  }

  const handleTextClick = () => {
    // Stop preview if playing
    if (isPreviewPlaying) {
      stopPreview()
    }
    playSong(song)
    setPlayerOpen(true)
  }

  const handleAddToPlaylist = (e: React.MouseEvent) => {
    e.stopPropagation()
    setShowMenu(false)
    openAddToPlaylist(song)
  }

  if (variant === 'list') {
    return (
      <div
        className={cn(
          'group flex items-center gap-3 w-full p-3 rounded-xl transition-all',
          shouldAnimate && 'duration-200',
          'hover:bg-card',
          isCurrentSong && 'bg-card'
        )}
      >
        {index !== undefined && (
          <span className="w-5 text-sm text-muted-foreground font-medium">
            {index + 1}
          </span>
        )}
        {/* Image - Preview on click */}
        <button
          onClick={handleImageClick}
          className={cn(
            'relative w-12 h-12 rounded-lg overflow-hidden flex-shrink-0',
            shouldAnimate && 'transition-transform duration-200 active:scale-95',
            isThisPreview && isPreviewPlaying && 'ring-2 ring-accent'
          )}
        >
          <Image
            src={song.coverImage}
            alt={song.title}
            fill
            className="object-cover"
            sizes="48px"
          />
          <div className={cn(
            'absolute inset-0 bg-black/50 flex items-center justify-center',
            isThisPreview && isPreviewPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100',
            shouldAnimate && 'transition-opacity duration-200'
          )}>
            {isThisPreview && isPreviewPlaying ? (
              <div className="flex items-center gap-1">
                <Volume2 className="w-4 h-4 text-accent animate-pulse" />
              </div>
            ) : (
              <Play className="w-5 h-5 text-white fill-white" />
            )}
          </div>
          {isCurrentSong && isPlaying && !isThisPreview && (
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
              <div className="flex gap-0.5 items-end h-4">
                <span className="w-1 bg-accent animate-pulse" style={{ height: '60%' }} />
                <span className="w-1 bg-accent animate-pulse" style={{ height: '100%', animationDelay: '0.1s' }} />
                <span className="w-1 bg-accent animate-pulse" style={{ height: '40%', animationDelay: '0.2s' }} />
              </div>
            </div>
          )}
        </button>
        
        {/* Text - Full player on click */}
        <button
          onClick={handleTextClick}
          className="flex-1 min-w-0 text-left"
        >
          <p className={cn(
            'font-semibold text-[15px] truncate',
            isCurrentSong ? 'text-accent' : 'text-foreground'
          )}>
            {song.title}
          </p>
          {showArtist && (
            <p className="text-sm text-muted-foreground truncate">{song.artist}</p>
          )}
        </button>
        
        <button
          onClick={(e) => {
            e.stopPropagation()
            toggleLike(song)
          }}
          className={cn(
            'p-2 rounded-full opacity-0 group-hover:opacity-100',
            shouldAnimate && 'transition-all duration-200',
            liked && 'opacity-100'
          )}
        >
          <Heart className={cn(
            'w-5 h-5',
            liked ? 'fill-accent text-accent' : 'text-muted-foreground'
          )} />
        </button>
        
        {/* More options menu */}
        <div className="relative">
          <button
            onClick={(e) => {
              e.stopPropagation()
              setShowMenu(!showMenu)
            }}
            className={cn(
              'p-2 rounded-full opacity-0 group-hover:opacity-100',
              shouldAnimate && 'transition-opacity duration-200',
              showMenu && 'opacity-100'
            )}
          >
            <MoreHorizontal className="w-5 h-5 text-muted-foreground" />
          </button>
          
          {showMenu && (
            <>
              <div 
                className="fixed inset-0 z-40" 
                onClick={() => setShowMenu(false)} 
              />
              <div className="absolute right-0 top-full mt-1 z-50 bg-card rounded-lg shadow-xl border border-border py-1 min-w-[160px]">
                <button
                  onClick={handleAddToPlaylist}
                  className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-secondary text-left"
                >
                  <Plus className="w-4 h-4" />
                  Add to Playlist
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    toggleLike(song)
                    setShowMenu(false)
                  }}
                  className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-secondary text-left"
                >
                  <Heart className={cn('w-4 h-4', liked && 'fill-accent text-accent')} />
                  {liked ? 'Remove from Liked' : 'Add to Liked'}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    )
  }

  if (variant === 'compact') {
    return (
      <div
        className={cn(
          'group flex items-center gap-3 w-full p-2 rounded-lg',
          shouldAnimate && 'transition-all duration-200',
          'hover:bg-card'
        )}
      >
        {/* Image - Preview */}
        <button
          onClick={handleImageClick}
          className={cn(
            'relative w-10 h-10 rounded-md overflow-hidden flex-shrink-0',
            shouldAnimate && 'transition-transform duration-200 active:scale-95',
            isThisPreview && isPreviewPlaying && 'ring-2 ring-accent'
          )}
        >
          <Image
            src={song.coverImage}
            alt={song.title}
            fill
            className="object-cover"
            sizes="40px"
          />
          {isThisPreview && isPreviewPlaying && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <Volume2 className="w-3 h-3 text-accent animate-pulse" />
            </div>
          )}
        </button>
        
        {/* Text - Full player */}
        <button
          onClick={handleTextClick}
          className="flex-1 min-w-0 text-left"
        >
          <p className="font-medium text-sm truncate">{song.title}</p>
          <p className="text-xs text-muted-foreground truncate">{song.artist}</p>
        </button>
        
        <button
          onClick={handleAddToPlaylist}
          className={cn(
            'p-1.5 rounded-full opacity-0 group-hover:opacity-100',
            shouldAnimate && 'transition-opacity duration-200'
          )}
        >
          <Plus className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>
    )
  }

  // Default card variant
  return (
    <div
      className={cn(
        'group flex flex-col w-[140px] flex-shrink-0',
        shouldAnimate && 'transition-transform duration-200'
      )}
    >
      {/* Image - Preview on click */}
      <button
        onClick={handleImageClick}
        className={cn(
          'relative aspect-square w-full rounded-xl overflow-hidden mb-2',
          shouldAnimate && 'transition-transform duration-200 active:scale-[0.97]',
          isThisPreview && isPreviewPlaying && 'ring-2 ring-accent ring-offset-2 ring-offset-background'
        )}
      >
        <Image
          src={song.coverImage}
          alt={song.title}
          fill
          className="object-cover"
          sizes="140px"
        />
        <div className={cn(
          'absolute inset-0 bg-black/40 flex items-center justify-center',
          isThisPreview && isPreviewPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100',
          shouldAnimate && 'transition-opacity duration-200'
        )}>
          {isThisPreview && isPreviewPlaying ? (
            <div className={cn(
              'w-12 h-12 rounded-full bg-accent flex items-center justify-center',
              shouldAnimate && 'transition-transform duration-200'
            )}>
              <Pause className="w-6 h-6 text-accent-foreground" />
            </div>
          ) : (
            <div className={cn(
              'w-12 h-12 rounded-full bg-accent flex items-center justify-center',
              shouldAnimate && 'transition-transform duration-200 scale-90 group-hover:scale-100'
            )}>
              <Play className="w-6 h-6 text-accent-foreground fill-accent-foreground ml-1" />
            </div>
          )}
        </div>
        {isThisPreview && isPreviewPlaying && (
          <div className="absolute bottom-2 left-2 bg-black/70 rounded-full px-2 py-1 flex items-center gap-1">
            <Volume2 className="w-3 h-3 text-accent" />
            <span className="text-xs text-white">Preview</span>
          </div>
        )}
      </button>
      
      {/* Text - Full player on click */}
      <button
        onClick={handleTextClick}
        className="text-left"
      >
        <p className="font-semibold text-[15px] truncate w-full">{song.title}</p>
        {showArtist && (
          <p className="text-sm text-muted-foreground truncate w-full">{song.artist}</p>
        )}
      </button>
    </div>
  )
}
