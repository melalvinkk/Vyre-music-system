'use client'

import { useState } from 'react'
import Image from 'next/image'
import { Play, X, Shuffle, Music } from 'lucide-react'
import { useMusicStore, type Playlist } from '@/lib/store'
import { SongCard } from '@/components/song-card'
import { cn } from '@/lib/utils'

interface PlaylistCardProps {
  playlist: Playlist
  variant?: 'default' | 'large'
}

export function PlaylistCard({ playlist, variant = 'default' }: PlaylistCardProps) {
  const { playQueue, settings } = useMusicStore()
  const [showDetails, setShowDetails] = useState(false)
  const shouldAnimate = !settings.lowStimulusMode && !settings.performanceMode

  const coverImage = playlist.coverImage || playlist.songs[0]?.coverImage || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&h=400&fit=crop'

  const handlePlay = (e?: React.MouseEvent) => {
    e?.stopPropagation()
    if (playlist.songs.length > 0) {
      playQueue(playlist.songs)
    }
  }

  const handleShuffle = () => {
    if (playlist.songs.length > 0) {
      const shuffled = [...playlist.songs].sort(() => Math.random() - 0.5)
      playQueue(shuffled)
    }
  }

  if (variant === 'large') {
    return (
      <>
        <div
          onClick={() => setShowDetails(true)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && setShowDetails(true)}
          className={cn(
            'group relative w-full aspect-square rounded-2xl overflow-hidden cursor-pointer',
            shouldAnimate && 'transition-transform duration-200',
            'active:scale-[0.98]'
          )}
        >
          <Image
            src={coverImage}
            alt={playlist.name}
            fill
            className="object-cover"
            sizes="(max-width: 768px) 50vw, 200px"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <p className="font-bold text-lg text-white">{playlist.name}</p>
            <p className="text-sm text-white/70">{playlist.songs.length} songs</p>
          </div>
          <button
            onClick={handlePlay}
            className={cn(
              'absolute top-3 right-3 w-10 h-10 rounded-full bg-accent flex items-center justify-center',
              'opacity-0 group-hover:opacity-100',
              shouldAnimate && 'transition-all duration-200 translate-y-2 group-hover:translate-y-0'
            )}
          >
            <Play className="w-5 h-5 text-accent-foreground fill-accent-foreground ml-0.5" />
          </button>
        </div>

        {/* Playlist Details Modal */}
        {showDetails && (
          <PlaylistDetailsModal
            playlist={playlist}
            coverImage={coverImage}
            onClose={() => setShowDetails(false)}
            onPlay={handlePlay}
            onShuffle={handleShuffle}
            shouldAnimate={shouldAnimate}
          />
        )}
      </>
    )
  }

  return (
    <>
      <div
        onClick={() => setShowDetails(true)}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === 'Enter' && setShowDetails(true)}
        className={cn(
          'group flex flex-col w-[160px] flex-shrink-0 cursor-pointer',
          shouldAnimate && 'transition-transform duration-200',
          'active:scale-[0.97]'
        )}
      >
        <div className="relative aspect-square w-full rounded-xl overflow-hidden mb-2">
          <Image
            src={coverImage}
            alt={playlist.name}
            fill
            className="object-cover"
            sizes="160px"
          />
          <div className={cn(
            'absolute inset-0 bg-black/40 flex items-center justify-center opacity-0',
            'group-hover:opacity-100',
            shouldAnimate && 'transition-opacity duration-200'
          )}>
            <div className={cn(
              'w-12 h-12 rounded-full bg-accent flex items-center justify-center',
              shouldAnimate && 'transition-transform duration-200 scale-90 group-hover:scale-100'
            )}>
              <Play className="w-6 h-6 text-accent-foreground fill-accent-foreground ml-1" />
            </div>
          </div>
        </div>
        <p className="font-semibold text-[15px] truncate w-full text-left">{playlist.name}</p>
        <p className="text-sm text-muted-foreground truncate w-full text-left">
          {playlist.songs.length} songs
        </p>
      </div>

      {/* Playlist Details Modal */}
      {showDetails && (
        <PlaylistDetailsModal
          playlist={playlist}
          coverImage={coverImage}
          onClose={() => setShowDetails(false)}
          onPlay={handlePlay}
          onShuffle={handleShuffle}
          shouldAnimate={shouldAnimate}
        />
      )}
    </>
  )
}

interface PlaylistDetailsModalProps {
  playlist: Playlist
  coverImage: string
  onClose: () => void
  onPlay: () => void
  onShuffle: () => void
  shouldAnimate: boolean
}

function PlaylistDetailsModal({ 
  playlist, 
  coverImage, 
  onClose, 
  onPlay, 
  onShuffle,
  shouldAnimate 
}: PlaylistDetailsModalProps) {
  return (
    <div className="fixed inset-0 z-[60] bg-black">
      <div className={cn(
        'h-full flex flex-col',
        shouldAnimate && 'animate-in slide-in-from-bottom duration-300'
      )}>
        {/* Header with gradient */}
        <div className="relative">
          {/* Background blur */}
          <div className="absolute inset-0 overflow-hidden">
            <Image
              src={coverImage}
              alt=""
              fill
              className="object-cover blur-3xl opacity-40 scale-150"
              sizes="100vw"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/80 to-black" />
          </div>
          
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
          
          {/* Playlist info */}
          <div className="relative pt-16 pb-6 px-5 flex items-end gap-4">
            <div className="relative w-32 h-32 rounded-xl overflow-hidden shadow-2xl flex-shrink-0">
              <Image
                src={coverImage}
                alt={playlist.name}
                fill
                className="object-cover"
                sizes="128px"
              />
            </div>
            <div className="flex-1 min-w-0 pb-2">
              <p className="text-xs font-medium text-white/60 uppercase tracking-wider mb-1">Playlist</p>
              <h1 className="text-2xl font-bold truncate">{playlist.name}</h1>
              <p className="text-sm text-white/60 mt-1">{playlist.songs.length} songs</p>
            </div>
          </div>
          
          {/* Action buttons */}
          <div className="relative px-5 pb-4 flex items-center gap-3">
            <button
              onClick={onPlay}
              disabled={playlist.songs.length === 0}
              className={cn(
                'flex items-center gap-2 px-6 py-3 bg-accent text-accent-foreground rounded-full font-semibold',
                shouldAnimate && 'transition-transform duration-150 active:scale-95',
                playlist.songs.length === 0 && 'opacity-50 cursor-not-allowed'
              )}
            >
              <Play className="w-5 h-5 fill-current" />
              Play
            </button>
            <button
              onClick={onShuffle}
              disabled={playlist.songs.length === 0}
              className={cn(
                'w-12 h-12 rounded-full bg-white/10 flex items-center justify-center',
                shouldAnimate && 'transition-transform duration-150 active:scale-95',
                playlist.songs.length === 0 && 'opacity-50 cursor-not-allowed'
              )}
            >
              <Shuffle className="w-5 h-5" />
            </button>
          </div>
        </div>
        
        {/* Songs list */}
        <div className="flex-1 overflow-y-auto px-3 pb-20">
          {playlist.songs.length > 0 ? (
            <div className="space-y-1">
              {playlist.songs.map((song, index) => (
                <SongCard key={song.id} song={song} variant="list" index={index} />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="w-16 h-16 rounded-full bg-card flex items-center justify-center mb-4">
                <Music className="w-8 h-8 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground">This playlist is empty</p>
              <p className="text-sm text-muted-foreground mt-1">Add songs to get started</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
