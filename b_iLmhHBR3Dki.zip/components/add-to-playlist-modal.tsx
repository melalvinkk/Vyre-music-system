'use client'

import { useState } from 'react'
import Image from 'next/image'
import { X, Plus, Check, Music } from 'lucide-react'
import { useMusicStore } from '@/lib/store'
import { cn } from '@/lib/utils'

export function AddToPlaylistModal() {
  const { 
    addToPlaylistOpen, 
    addToPlaylistSong, 
    closeAddToPlaylist,
    playlists,
    addToPlaylist,
    createPlaylist,
    settings
  } = useMusicStore()
  
  const [showCreate, setShowCreate] = useState(false)
  const [newPlaylistName, setNewPlaylistName] = useState('')
  const [addedTo, setAddedTo] = useState<string[]>([])
  
  const shouldAnimate = !settings.lowStimulusMode && !settings.performanceMode

  if (!addToPlaylistOpen || !addToPlaylistSong) return null

  const handleAddToPlaylist = (playlistId: string) => {
    addToPlaylist(playlistId, addToPlaylistSong)
    setAddedTo(prev => [...prev, playlistId])
    
    // Show checkmark briefly then close
    setTimeout(() => {
      closeAddToPlaylist()
      setAddedTo([])
    }, 500)
  }

  const handleCreatePlaylist = () => {
    if (newPlaylistName.trim()) {
      createPlaylist(newPlaylistName.trim())
      setNewPlaylistName('')
      setShowCreate(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      {/* Backdrop */}
      <div 
        className={cn(
          'absolute inset-0 bg-black/60 backdrop-blur-sm',
          shouldAnimate && 'animate-in fade-in duration-200'
        )}
        onClick={closeAddToPlaylist}
      />
      
      {/* Modal */}
      <div className={cn(
        'relative w-full max-w-md bg-card rounded-t-3xl sm:rounded-2xl p-6 pb-8 max-h-[80vh] overflow-hidden flex flex-col',
        shouldAnimate && 'animate-in slide-in-from-bottom-4 duration-300'
      )}>
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Add to Playlist</h2>
          <button
            onClick={closeAddToPlaylist}
            className="p-2 -mr-2 rounded-full hover:bg-secondary transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        {/* Song info */}
        <div className="flex items-center gap-3 p-3 bg-secondary/50 rounded-xl mb-4">
          <div className="relative w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
            <Image
              src={addToPlaylistSong.coverImage}
              alt={addToPlaylistSong.title}
              fill
              className="object-cover"
              sizes="48px"
            />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-semibold truncate">{addToPlaylistSong.title}</p>
            <p className="text-sm text-muted-foreground truncate">{addToPlaylistSong.artist}</p>
          </div>
        </div>
        
        {/* Create new playlist button */}
        {!showCreate ? (
          <button
            onClick={() => setShowCreate(true)}
            className="flex items-center gap-3 w-full p-3 rounded-xl hover:bg-secondary transition-colors mb-2"
          >
            <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center">
              <Plus className="w-6 h-6" />
            </div>
            <span className="font-medium">Create New Playlist</span>
          </button>
        ) : (
          <div className="flex gap-2 mb-2">
            <input
              type="text"
              value={newPlaylistName}
              onChange={(e) => setNewPlaylistName(e.target.value)}
              placeholder="Playlist name"
              className="flex-1 px-4 py-3 bg-secondary rounded-xl text-sm outline-none focus:ring-2 ring-accent"
              autoFocus
              onKeyDown={(e) => e.key === 'Enter' && handleCreatePlaylist()}
            />
            <button
              onClick={handleCreatePlaylist}
              disabled={!newPlaylistName.trim()}
              className="px-4 py-3 bg-accent text-accent-foreground rounded-xl font-medium disabled:opacity-50"
            >
              Create
            </button>
          </div>
        )}
        
        {/* Playlists list */}
        <div className="flex-1 overflow-y-auto -mx-2 px-2">
          {playlists.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <Music className="w-12 h-12 text-muted-foreground mb-3" />
              <p className="text-muted-foreground">No playlists yet</p>
              <p className="text-sm text-muted-foreground">Create one to get started</p>
            </div>
          ) : (
            <div className="space-y-1">
              {playlists.map(playlist => {
                const isAdded = addedTo.includes(playlist.id)
                const alreadyInPlaylist = playlist.songs.some(s => s.id === addToPlaylistSong.id)
                
                return (
                  <button
                    key={playlist.id}
                    onClick={() => !alreadyInPlaylist && handleAddToPlaylist(playlist.id)}
                    disabled={alreadyInPlaylist}
                    className={cn(
                      'flex items-center gap-3 w-full p-3 rounded-xl transition-colors',
                      alreadyInPlaylist ? 'opacity-50 cursor-not-allowed' : 'hover:bg-secondary'
                    )}
                  >
                    <div className="relative w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 bg-secondary">
                      {playlist.coverImage || playlist.songs[0]?.coverImage ? (
                        <Image
                          src={playlist.coverImage || playlist.songs[0]?.coverImage}
                          alt={playlist.name}
                          fill
                          className="object-cover"
                          sizes="48px"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Music className="w-6 h-6 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0 text-left">
                      <p className="font-medium truncate">{playlist.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {playlist.songs.length} {playlist.songs.length === 1 ? 'song' : 'songs'}
                      </p>
                    </div>
                    {isAdded ? (
                      <Check className="w-5 h-5 text-accent" />
                    ) : alreadyInPlaylist ? (
                      <span className="text-xs text-muted-foreground">Added</span>
                    ) : null}
                  </button>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
