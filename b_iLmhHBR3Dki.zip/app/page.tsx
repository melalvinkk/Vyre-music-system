'use client'

import { useState } from 'react'
import { Navbar } from '@/components/navbar'
import { MiniPlayer } from '@/components/mini-player'
import { Player } from '@/components/player'
import { ColorController } from '@/components/color-controller'
import { AddToPlaylistModal } from '@/components/add-to-playlist-modal'
import { HomeScreen } from '@/components/screens/home-screen'
import { SearchScreen } from '@/components/screens/search-screen'
import { LibraryScreen } from '@/components/screens/library-screen'
import { useMusicStore } from '@/lib/store'
import { cn } from '@/lib/utils'

type Tab = 'home' | 'search' | 'library'

export default function VyreApp() {
  const [activeTab, setActiveTab] = useState<Tab>('home')
  const { currentSong, playerOpen, settings } = useMusicStore()
  const shouldAnimate = !settings.lowStimulusMode && !settings.performanceMode

  return (
    <div className="min-h-screen bg-black">
      {/* Main Content */}
      <main className={cn(
        'relative overflow-y-auto',
        shouldAnimate && 'transition-all duration-200'
      )}>
        {activeTab === 'home' && <HomeScreen />}
        {activeTab === 'search' && <SearchScreen />}
        {activeTab === 'library' && <LibraryScreen />}
      </main>

      {/* Mini Player (shows when player is not open and there's a current song) */}
      {currentSong && !playerOpen && <MiniPlayer />}

      {/* Bottom Navigation */}
      <Navbar activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Full Screen Player */}
      <Player />

      {/* Customization Panel */}
      <ColorController />

      {/* Add to Playlist Modal */}
      <AddToPlaylistModal />

      {/* Hide scrollbar globally for mobile feel */}
      <style jsx global>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        
        /* Custom range input styling */
        input[type="range"] {
          -webkit-appearance: none;
          background: transparent;
        }
        
        input[type="range"]::-webkit-slider-thumb {
          -webkit-appearance: none;
          height: 16px;
          width: 16px;
          border-radius: 50%;
          background: #ffffff;
          cursor: pointer;
          margin-top: -7px;
        }
        
        input[type="range"]::-webkit-slider-runnable-track {
          width: 100%;
          height: 4px;
          cursor: pointer;
          background: #333;
          border-radius: 4px;
        }
        
        input[type="range"]::-moz-range-thumb {
          height: 16px;
          width: 16px;
          border-radius: 50%;
          background: #ffffff;
          cursor: pointer;
          border: none;
        }
        
        input[type="range"]::-moz-range-track {
          width: 100%;
          height: 4px;
          cursor: pointer;
          background: #333;
          border-radius: 4px;
        }
      `}</style>
    </div>
  )
}
