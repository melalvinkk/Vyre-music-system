import { NextResponse } from 'next/server'

// Search queries for real songs we want to fetch
const songQueries = [
  'Best Friend Rex Orange County',
  'Blinding Lights The Weeknd',
  'As It Was Harry Styles',
  'Heat Waves Glass Animals',
  'Levitating Dua Lipa',
  'Sunflower Rex Orange County',
  'Stay Kid LAROI Justin Bieber',
  'Watermelon Sugar Harry Styles',
  'Peaches Justin Bieber',
  'drivers license Olivia Rodrigo',
  'good 4 u Olivia Rodrigo',
  'Loving is Easy Rex Orange County',
  'Shivers Ed Sheeran',
  'Bad Habits Ed Sheeran',
  'Butter BTS',
  'Dynamite BTS',
]

const dominantColors = [
  '#E8A87C', '#DC2626', '#8B5CF6', '#F59E0B',
  '#EC4899', '#FBBF24', '#06B6D4', '#10B981',
  '#F472B6', '#6366F1', '#A855F7', '#84CC16',
  '#3B82F6', '#7C3AED', '#FCD34D', '#F97316',
]

export async function GET() {
  try {
    const songs = await Promise.all(
      songQueries.map(async (query, index) => {
        try {
          const response = await fetch(
            `https://api.deezer.com/search?q=${encodeURIComponent(query)}&limit=1`
          )
          const data = await response.json()
          
          if (data.data && data.data.length > 0) {
            const track = data.data[0]
            return {
              id: String(index + 1),
              title: track.title_short || track.title,
              artist: track.artist.name,
              coverImage: track.album.cover_xl || track.album.cover_big || track.album.cover_medium,
              audioUrl: track.preview,
              previewUrl: track.preview,
              duration: track.duration,
              dominantColor: dominantColors[index],
              deezerId: track.id,
            }
          }
          return null
        } catch {
          return null
        }
      })
    )

    const validSongs = songs.filter(Boolean)
    
    return NextResponse.json({ songs: validSongs })
  } catch (error) {
    console.error('Error fetching songs:', error)
    return NextResponse.json({ error: 'Failed to fetch songs' }, { status: 500 })
  }
}
