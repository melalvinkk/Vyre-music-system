import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface Song {
  id: string
  title: string
  artist: string
  coverImage: string
  audioUrl: string
  previewUrl?: string
  duration: number
  dominantColor: string
}

export interface Playlist {
  id: string
  name: string
  songs: Song[]
  coverImage?: string
}

export type ColorPreset = 'auto' | 'chill' | 'neon' | 'minimal'

interface PlayerSettings {
  autoColor: boolean
  manualColor: string
  intensity: number
  preset: ColorPreset
  lowStimulusMode: boolean
  performanceMode: boolean
  swipeGestures: boolean
}

interface MusicState {
  // Player state
  currentSong: Song | null
  isPlaying: boolean
  currentTime: number
  duration: number
  volume: number
  queue: Song[]
  queueIndex: number
  history: Song[]
  
  // Preview state
  previewSong: Song | null
  isPreviewPlaying: boolean
  
  // Library state
  likedSongs: Song[]
  playlists: Playlist[]
  recentlyPlayed: Song[]
  
  // Settings
  settings: PlayerSettings
  playerOpen: boolean
  customizationOpen: boolean
  addToPlaylistOpen: boolean
  addToPlaylistSong: Song | null
  
  // Actions
  playSong: (song: Song) => void
  togglePlay: () => void
  setIsPlaying: (playing: boolean) => void
  nextSong: () => void
  previousSong: () => void
  undoSkip: () => void
  setCurrentTime: (time: number) => void
  setDuration: (duration: number) => void
  setVolume: (volume: number) => void
  
  toggleLike: (song: Song) => void
  isLiked: (songId: string) => boolean
  
  createPlaylist: (name: string) => void
  addToPlaylist: (playlistId: string, song: Song) => void
  removeFromPlaylist: (playlistId: string, songId: string) => void
  
  setPlayerOpen: (open: boolean) => void
  setCustomizationOpen: (open: boolean) => void
  
  // Preview actions
  startPreview: (song: Song) => void
  stopPreview: () => void
  
  // Add to playlist modal
  openAddToPlaylist: (song: Song) => void
  closeAddToPlaylist: () => void
  
  updateSettings: (settings: Partial<PlayerSettings>) => void
  
  addToQueue: (song: Song) => void
  playQueue: (songs: Song[], startIndex?: number) => void
}

export const useMusicStore = create<MusicState>()(
  persist(
    (set, get) => ({
      // Initial state
      currentSong: null,
      isPlaying: false,
      currentTime: 0,
      duration: 0,
      volume: 1,
      queue: [],
      queueIndex: 0,
      history: [],
      previewSong: null,
      isPreviewPlaying: false,
      likedSongs: [],
      playlists: [],
      recentlyPlayed: [],
      playerOpen: false,
      customizationOpen: false,
      addToPlaylistOpen: false,
      addToPlaylistSong: null,
      
      settings: {
        autoColor: true,
        manualColor: '#1DB954',
        intensity: 0.7,
        preset: 'auto',
        lowStimulusMode: false,
        performanceMode: false,
        swipeGestures: true,
      },
      
      // Actions
      playSong: (song) => {
        const { recentlyPlayed, currentSong } = get()
        const updatedRecent = currentSong 
          ? [currentSong, ...recentlyPlayed.filter(s => s.id !== currentSong.id)].slice(0, 20)
          : recentlyPlayed
        
        set({ 
          currentSong: song, 
          isPlaying: true, 
          currentTime: 0,
          recentlyPlayed: updatedRecent,
          playerOpen: true,
        })
      },
      
      togglePlay: () => set((state) => ({ isPlaying: !state.isPlaying })),
      
      setIsPlaying: (playing) => set({ isPlaying: playing }),
      
      nextSong: () => {
        const { queue, queueIndex, currentSong, history } = get()
        if (queueIndex < queue.length - 1) {
          const newHistory = currentSong ? [...history, currentSong] : history
          set({ 
            queueIndex: queueIndex + 1, 
            currentSong: queue[queueIndex + 1],
            currentTime: 0,
            isPlaying: true,
            history: newHistory,
          })
        }
      },
      
      previousSong: () => {
        const { queue, queueIndex, currentTime } = get()
        if (currentTime > 3) {
          set({ currentTime: 0 })
        } else if (queueIndex > 0) {
          set({ 
            queueIndex: queueIndex - 1, 
            currentSong: queue[queueIndex - 1],
            currentTime: 0,
            isPlaying: true,
          })
        }
      },
      
      undoSkip: () => {
        const { history } = get()
        if (history.length > 0) {
          const lastSong = history[history.length - 1]
          set({ 
            currentSong: lastSong,
            history: history.slice(0, -1),
            currentTime: 0,
            isPlaying: true,
          })
        }
      },
      
      setCurrentTime: (time) => set({ currentTime: time }),
      setDuration: (duration) => set({ duration }),
      setVolume: (volume) => set({ volume }),
      
      toggleLike: (song) => {
        const { likedSongs } = get()
        const isLiked = likedSongs.some(s => s.id === song.id)
        set({
          likedSongs: isLiked 
            ? likedSongs.filter(s => s.id !== song.id)
            : [...likedSongs, song]
        })
      },
      
      isLiked: (songId) => get().likedSongs.some(s => s.id === songId),
      
      createPlaylist: (name) => {
        const newPlaylist: Playlist = {
          id: Date.now().toString(),
          name,
          songs: [],
        }
        set((state) => ({ playlists: [...state.playlists, newPlaylist] }))
      },
      
      addToPlaylist: (playlistId, song) => {
        set((state) => ({
          playlists: state.playlists.map(p => 
            p.id === playlistId 
              ? { ...p, songs: [...p.songs.filter(s => s.id !== song.id), song] }
              : p
          )
        }))
      },
      
      removeFromPlaylist: (playlistId, songId) => {
        set((state) => ({
          playlists: state.playlists.map(p => 
            p.id === playlistId 
              ? { ...p, songs: p.songs.filter(s => s.id !== songId) }
              : p
          )
        }))
      },
      
      setPlayerOpen: (open) => set({ playerOpen: open }),
      setCustomizationOpen: (open) => set({ customizationOpen: open }),
      
      startPreview: (song) => set({ previewSong: song, isPreviewPlaying: true }),
      stopPreview: () => set({ previewSong: null, isPreviewPlaying: false }),
      
      openAddToPlaylist: (song) => set({ addToPlaylistOpen: true, addToPlaylistSong: song }),
      closeAddToPlaylist: () => set({ addToPlaylistOpen: false, addToPlaylistSong: null }),
      
      updateSettings: (newSettings) => {
        set((state) => ({ 
          settings: { ...state.settings, ...newSettings } 
        }))
      },
      
      addToQueue: (song) => {
        set((state) => ({ queue: [...state.queue, song] }))
      },
      
      playQueue: (songs, startIndex = 0) => {
        set({ 
          queue: songs, 
          queueIndex: startIndex, 
          currentSong: songs[startIndex],
          isPlaying: true,
          currentTime: 0,
          playerOpen: true,
        })
      },
    }),
    {
      name: 'vyre-music-storage',
      partialize: (state) => ({
        likedSongs: state.likedSongs,
        playlists: state.playlists,
        recentlyPlayed: state.recentlyPlayed,
        settings: state.settings,
        volume: state.volume,
      }),
    }
  )
)
