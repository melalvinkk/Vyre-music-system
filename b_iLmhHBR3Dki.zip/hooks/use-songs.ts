'use client'

import useSWR from 'swr'
import type { Song } from '@/lib/store'

const fetcher = (url: string) => fetch(url).then(res => res.json())

export function useSongs() {
  const { data, error, isLoading } = useSWR('/api/songs', fetcher, {
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
    dedupingInterval: 60000 * 10, // Cache for 10 minutes
  })

  return {
    songs: (data?.songs || []) as Song[],
    isLoading,
    error,
  }
}

export function useRecommendedSongs() {
  const { songs, isLoading, error } = useSongs()
  return {
    songs: songs.slice(0, 8),
    isLoading,
    error,
  }
}

export function useRecentlyPlayed() {
  const { songs, isLoading, error } = useSongs()
  return {
    songs: songs.slice(4, 10),
    isLoading,
    error,
  }
}

export function searchSongs(songs: Song[], query: string): Song[] {
  const lowerQuery = query.toLowerCase()
  return songs.filter(
    song => 
      song.title.toLowerCase().includes(lowerQuery) ||
      song.artist.toLowerCase().includes(lowerQuery)
  )
}
